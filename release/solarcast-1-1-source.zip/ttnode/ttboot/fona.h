// Copyright 2017 Inca Roads LLC.  All rights reserved.
// Use of this source code is governed by licenses granted by the
// copyright holder including that found in the LICENSE file.

#ifndef FONA_DFU_H__
#define FONA_DFU_H__

bool fona_dfu_init();
void fona_dfu_term();

#endif // FONA_DFU_H__
